let body = document.querySelector("body");

$(document).ready(function() {
    $("#btnCreate").on("click", createElement);
    $("#btnDelete").on("click", deleteDiv);
    $("#btnHide").on("click", hideDiv);
    $("#btnShow").on("click", showDiv);

    setInterval('changeBackgroundColorInterval(body)', 300);
    //setTimeout('changeBackgroundColor("blue", body)', 2000)
    //alert("Myscript and JQuery were loaded");
    //eval("alert('Hello from eval function.')");
});

// 1
function changeBackgroundColor1(color) {
    // do something
}

// 2
var changeBackgroundColor2 = function(color) {
    // do something
}

// 3 => lambda sintaxis or arrow functions
let changeBackgroundColor = (color, elem) => {
    $(elem).css("background", color);
    //$(elem).attr("style", "background:blue;");
    //$(elem).addClass("bg-color-2");
    //elem.style = "background-color: blue";
}

var ctlBackground = true;
let changeBackgroundColorInterval = (elem) => {
    if (ctlBackground) {
        $(elem).css("background", "#FFF");
    } else {
        $(elem).css("background", "#ddd");
    }
    ctlBackground = !ctlBackground;
}


// Buttons FUnctions
var divCounter = 1;
var createElement = () => {
    let newDiv = "<div id='div-id-" + divCounter + "' class='newDivClass'>Hello, I'm div " + divCounter + "</div>";
    $("#container").append(newDiv);
    divCounter++;
}

function deleteDiv() {
    let id = $("#txtIdToDelete").val();
    if (id != "") {
        if ($("#div-id-" + id).length > 0) {
            $("#div-id-" + id).remove();
        }
    }
}

function hideDiv() {
    let id = $("#txtIdToDelete").val();
    if (id != "") {
        if ($("#div-id-" + id).length > 0) {
            $("#div-id-" + id).hide("slow");
        }
    }
}

function showDiv() {
    let id = $("#txtIdToDelete").val();
    if (id != "") {
        if ($("#div-id-" + id).length > 0) {
            $("#div-id-" + id).show("slow");
        }
    }
}

let loadCities = () => {
    var idDepto = $("#selDepto").val();
    $.ajax({
        url: "data/info.json",
        data: {
            id: idDepto
        },
        success: function(result) {
            let info = JSON.parse(result);
            let options = "";
            $(info).each(function(index, obj) {
                if (obj.id_dep == idDepto) {
                    options += "<option value='" + obj.id + "'>" + obj.name + "</option>"
                }
                $("#selCities").html(options);
            });
        }
    });
};