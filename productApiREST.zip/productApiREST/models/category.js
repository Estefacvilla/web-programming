const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const CategorySchema = new Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: false
    }
});

const CategoryModel = mongoose.model('Category_Coll', CategorySchema);
module.exports = CategoryModel;