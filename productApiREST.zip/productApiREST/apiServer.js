// Requires or Imports
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const config = require('config');
const ProductDbSchema = require('./models/product');
const CategoryDbSchema = require('./models/category');
const cors = require('cors');

// Start services and settings
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const corsOptions = {
    origin: 'http://localhost:4200',
    optionsSuccessStatus: 200
}

app.use(cors(corsOptions));

// database connection
const connString = config.get('mongoURI');
mongoose.connect(connString, { useNewUrlParser: true, useCreateIndex: true, useFindAndModify: false })
    .then(() => console.log('mongodb connected...'))
    .catch(err => console.log('Error connecting: ' + err))

//  start server
app.listen(3000, () => {
    console.log('server has been started.');
})

// API Methods for Products and Categories

/** Main path */
app.get('/', (req, res) => {
    res.send('This is the api root.');
});

/** Get all products */
app.get('/api/products', (req, res) => {
    ProductDbSchema.find()
        .sort({ expiredDate: -1 })
        .then(items => res.status(200).send(items))
        .catch(err => res.status(500).send(err));
});

/** Get a product by code */
app.get('/api/product/:code', (req, res) => {
    let productCode = req.params['code'];
    ProductDbSchema.findOne({ code: productCode })
        .then(item => res.status(200).send(item))
        .catch(err => res.status(500).send(err));
});

/** Add a new product */
app.post('/api/product', (req, res) => {
    console.log(req.body);
    //delete req.body._id;
    const newProduct = ProductDbSchema(req.body);
    newProduct.save()
        .then(item => {
            console.log(item)
            res.status(200).send(item);
        })
        .catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
});

/** Update a existing product */
app.put('/api/product', (req, res) => {
    console.log(req.body);
    let _id = req.body._id;
    delete req.body._id;
    ProductDbSchema.findByIdAndUpdate(_id, req.body, { new: true })
        .then(item => {
            console.log('updated');
            res.status(200).send(item);
        })
        .catch(err => {
            console.log(err);
            res.status(500).send(err);
        })
});

/** Delete an existing product */
app.delete('/api/product', (req, res) => {
    ProductDbSchema.findByIdAndDelete(req.body._id)
        .then(item => {
            console.log('product removed');
            res.status(200).send(item);
        })
        .catch(err => {
            console.log(err);
            res.status(500).send(err);
        })
});

/** Get all categories */
app.get('/api/categories', (req, res) => {
    CategoryDbSchema.find()
        .then(items => {
            res.status(200).send(items);
        })
        .catch(err => {
            res.status(500).send(err);
        })
});

/** Get a category by name */
app.get('/api/category/:name', (req, res) => {
    CategoryDbSchema.find({ name: req.params.name })
        .then(items => {
            res.status(200).send(items);
        })
        .catch(err => {
            res.status(500).send(err);
        })
});


/** Add a new category */
app.post('/api/category', bodyParser.json(), (req, res) => {
    console.log(req.body)
    const newCategory = CategoryDbSchema({
        name: req.body.name,
        description: req.body.description
    });
    newCategory.save()
        .then(item => {
            console.log(item)
            res.status(200).send(item);
        })
        .catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
});

/** Update an existing category */
app.put('/api/category/', (req, res) => {
    console.log(req.body);
    let catId = req.body._id;
    console.log(catId);
    CategoryDbSchema.findByIdAndUpdate(catId, req.body, { new: true })
        .then(item => {
            console.log(item);
            res.status(200).send(item);
        })
        .catch(item => {
            console.log(err);
            res.status.send(item);
        });
});

/** Delete an existing category */

app.delete('/api/category/:id', (req, res) => {
    let catId = req.params.id;
    CategoryDbSchema.countDocuments({ category: catId }, (err, c) => {
        if (c == 0) {
            console.log(catId);
            CategoryDbSchema.findByIdAndDelete(catId)
                .then(item => {
                    console.log('category removed');
                    res.status(200).send(item);
                })
                .catch(err => {
                    console.log(err);
                    res.status(500).send(err);
                })
        } else {
            res.status(500).send('This category is associated with atleast one product.')
        }
    });

});