import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClientOperationsService } from '../client-operations.service';

@Component({
  selector: 'app-client-editor',
  templateUrl: './client-editor.component.html',
  styleUrls: ['./client-editor.component.css']
})

export class ClientEditorComponent implements OnInit {

  client = {
    id: null,
    name: null,
    age: null,
    balance: null,
    company: null,
    phone: null,
    email: null
  }

  constructor(private route: ActivatedRoute, private clientService: ClientOperationsService) { }

  id = null;

  getUrlParameter = (parameterName: string) => {
    return this.route.snapshot.paramMap.get(parameterName);
  }

  ngOnInit() {
    let id = this.getUrlParameter("clientId");

    let clientFound = this.clientService.searchClient(id);
    this.client.name = clientFound.name;
    this.client.age = clientFound.age;
    this.client.balance = clientFound.balance;
    this.client.company = clientFound.company;
    this.client.phone = clientFound.phone;
    this.client.email = clientFound.email;
    this.client.id = id;
  }

  updateClient(){
    if(this.client.id != null){
      this.clientService.updateClient(this.client);
      alert('Updated!');
    }
  }

}
