import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'Product Information';

  productName = 'Computer';
  serial = 'ABC123';
  historyPrice = [2000, 3000, 2500, 4600, 10000];
  stock = 12;
  currentPrice = 1500;
  description = 'This computer is the best!!!';
  isAvailableOnline = true;

  getPriceAVG(){
    let sum = this.historyPrice.reduce(this.getPriceSum);
    let avg = sum / this.historyPrice.length;
    return avg;
  }

  getPriceSum(total, price){
    return total+=price;
  }

  increaseStock(){
    this.stock += 1;
  }

  decreaseStock(){
    this.stock -= 1;
  }

  addPrice(){
    this.historyPrice.push(Math.random() * 10000);
  }

}

