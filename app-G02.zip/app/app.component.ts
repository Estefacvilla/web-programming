import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Student Information';
  name = 'Pepito';
  lastname = 'Pérez'
  age = 14;
  email = 'pepito@ucaldas.edu.co';
  grades = [4, 3.5, 5, 4.8, 1];
  semester = 1;

  isAdult(){
    if(this.age >= 18){
      return `${this.name} is adult.`;
    }else{
      return `${this.name} is not adult.`;
    }
  }

  getGradesAVG(){
    let sum = this.grades.reduce(this.getGradesSum);
    let avg = sum / this.grades.length;
    return avg;
  }

  getGradesSum(total, grade){
    return total += grade;
  }

  increasingAge(){
    this.age += 1;
  }

  DecreasingAge(){
    this.age -= 1;
  }

  AddGrade(){
    this.grades.push(Math.random());
  }

}
