import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'
import { ConfigurationRoutingModule } from './configuration-routing.module';
import { ProductComponent } from './product/product.component';
import { CategoryComponent } from './category/category.component';

@NgModule({
  declarations: [ProductComponent, CategoryComponent],
  imports: [
    CommonModule,
    ConfigurationRoutingModule,
    FormsModule
  ],
  exports: [
    ProductComponent, CategoryComponent
  ]
})
export class ConfigurationModule { }
