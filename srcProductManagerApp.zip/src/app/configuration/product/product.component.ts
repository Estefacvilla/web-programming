import { Component, OnInit } from '@angular/core';
import { ProductModel } from 'src/app/models/ProductModel';
import { ProductOperatorService } from 'src/app/services/product-operator.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  productList: ProductModel[] = [];

  product: ProductModel = {
    _id: null,
    code: null,
    name: null,
    categoryId: null,
    price: null,
    stock: null,
    description: null,
    expiredDate: null
  }

  constructor(private service: ProductOperatorService) { 
    this.loadProductData();
  }

  ngOnInit() {
  }

  saveProductData(): void {
    this.service.saveProduct(this.product).subscribe(prod => {
      console.log(prod);
      this.productList.push(prod);
      alert('Product saved');
    });
  }


  loadProductData(): void {
    this.service.loadProduct().subscribe(prodList => {
      console.log(prodList);
      this.productList = prodList;
    });
  }

}
