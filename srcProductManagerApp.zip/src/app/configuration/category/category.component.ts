import { Component, OnInit } from '@angular/core';
import { CategoryModel } from 'src/app/models/CategoryModel';
import { CategoryOperatorService } from '../../services/category-operator.service';


@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  flagValidationToDelete: Boolean = true;
  idToDelete: string = null;
  categoriesList: CategoryModel[] = [];
  category: CategoryModel = {
    _id: null,
    name: null,
    description: null
  }

  constructor(private service: CategoryOperatorService) {
    this.loadCategoiesList();
  }

  ngOnInit() {
  }

  loadCategoiesList() {
    this.service.getAllCategories().subscribe(res => this.categoriesList = res);
  }

  saveCategoryData(): void {
    if (this.category._id != null) {
      this.UpdateCategory()
    } else {
      this.AddNewCategory();
    }
  }

  AddNewCategory(): void {
    this.service.addNewCategory(this.category).subscribe((res: CategoryModel) => {
      //console.log(res);
      this.categoriesList.push(res);
      this.clearFields();
      alert("Category has been saved.")
    }, (err: any) => {
      //console.log(err);
      alert("Error processing the request.")
    });
  }

  UpdateCategory(): void {
    console.log("antes de enviar a editar")
    console.log(this.category)
    this.service.updateCategory(this.category).subscribe((res: CategoryModel) => {
      console.log(res);
      //this.categoriesList.push(res);
      let currentData = this.categoriesList.find(c => c._id == this.category._id);
      currentData.name = this.category.name;
      currentData.description = this.category.description;
      this.clearFields();
      alert("Category has been updated.")
    }, (err: any) => {
      console.log(err);
      alert("Error processing the request.")
    });
  }

  ChangeFlagValidation(id): void {
    this.flagValidationToDelete = !this.flagValidationToDelete;
    this.idToDelete = id;
  }

  DeleteCategory(): void {
    this.service.DeleteCategory(this.idToDelete).subscribe((res: any) => {
      console.log(res);
      let currentIndex = this.categoriesList.findIndex(c => c._id == this.idToDelete);
      this.categoriesList.splice(currentIndex, 1);
      this.ChangeFlagValidation(null);
      alert("Category has been deleted.")
    }, (err: any) => {
      //console.log(err);
      alert("Error processing the request.")
    });
  }

  EditCategory(cat): void {
    this.category = {
      _id: cat._id,
      name: cat.name,
      description: cat.description
    }
  }

  clearFields() {
    this.category = {
      _id: null,
      name: null,
      description: null
    }
  }

}
