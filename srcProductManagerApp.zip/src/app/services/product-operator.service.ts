import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { ProductModel } from '../models/ProductModel';
import { Observable } from 'rxjs';

const base_URL = 'http://localhost:3000/api/';

@Injectable({
  providedIn: 'root'
})

export class ProductOperatorService {

  constructor(private http: HttpClient) { }

  saveProduct(product: ProductModel): Observable<ProductModel> {
    return this.http.post<ProductModel>(`${base_URL}product`,
      product,
      {
        headers: new HttpHeaders({
          'Content-Type':'application/json'
        })
      });
  }


  loadProduct(): Observable<ProductModel[]> {
    return this.http.get<ProductModel[]>(`${base_URL}products`);
  }
}
