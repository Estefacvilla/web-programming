import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { CategoryModel } from '../models/CategoryModel';
import { Observable } from 'rxjs';

const base_URL = "http://localhost:3000/api/";

@Injectable({
  providedIn: 'root'
})
export class CategoryOperatorService {
  constructor(private http: HttpClient) { }

  getAllCategories(): Observable<CategoryModel[]> {
    return this.http.get<CategoryModel[]>(`${base_URL}categories`);
  }

  addNewCategory(cat: CategoryModel): Observable<CategoryModel> {
    return this.http.post<CategoryModel>(`${base_URL}category/`,
      cat,
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      });
  }

  updateCategory(cat: CategoryModel): Observable<CategoryModel> {
    console.log("en el servicio")
    console.log(cat)
    return this.http.put<CategoryModel>(`${base_URL}category/`,
      {
        _id: cat._id,
        name: cat.name,
        description: cat.description
      },
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      });
  }

  DeleteCategory(catId: string): Observable<void> {
    console.log(catId);
    return this.http.delete<void>(`${base_URL}category/${catId}`)
  }

}
