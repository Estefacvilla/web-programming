export class ProductModel{
    _id: string;
    code: string;
    name: string;
    price: number;
    categoryId: string;
    stock: number;
    expiredDate: Date;
    description: string;
}