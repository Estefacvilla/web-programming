// Definición de atributos de objetos con el mismo nombre de la variable.
const name = 'Pepito';
const age = 18;

const obj = {
    name,
    age
}

obj.name = 'Juanito Alimaña';
console.log(obj.name);

// acceso a los atributos del mismo objeto a través de this
console.log(`
-------------------------
`)
let person = {
    name: 'Pedrito',
    age: 25,
    salary: [2000, 5000, 3500, 1800],
    getSalaryAVG() {
        let sum = 0;
        this.salary.forEach(s => {
            sum += s;
        });
        let avg = sum / this.salary.length;
        console.log("Salary AVG: ", avg);
    }
}

person.getSalaryAVG();

// nombre de atributos computados
console.log(`
-------------------------
`)
var element = 'athletics'
var type = 'run'

function sport() {
    return 'marathon';
}

var sportsObj = {
    [sport()]: element,
    [type + '100m']: 'type: run 100 meters',
    [type + '200m']: 'type: run 200 meters',
}

console.log(sportsObj);