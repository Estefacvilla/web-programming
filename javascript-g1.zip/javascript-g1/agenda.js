// variables var, let y const

// Destructuring vars
// let [a,b,c] = [1,2,3];
// let {x = 5, y = 8, z = 13} = {x: 10, y: 20};
// console.log(x,y,z); //10, 20, 13
// alias de variables 
// let {x:newX,y:newY,z:newZ} = {x: 10, y: 20, z: 30};
// console.log(newX,newY,newZ);

// funciones con let y var

// ejemplo de const inicializada

// ejemplo de const sin inicializar e inicializándola en la siguiente línea

// ejemplo de una const = a un objeto y se cambia uno de los atributos del objeto y se imprime

// explicación de la doble lectura de JS y los ámbitos de las variables var y let

// ejemplo de definición de un objeto y sus atributos como funciones y acceso con this desde la función a otro atributo del objeto

// explicación de la definición de objeto con variables con el mismo nombre de los atributos del objeto (abreviados en ES6)

// explicación de definición de nombre de atributos computados

var element = 'athletics'
var type = 'run'

function sport() {
    return 'marathon'
}

var sports = {
    [sport()]: element,
    [type + '100m']: 'type: run 100 meters',
    [type + '200m']: 'type: run 200 meters',
}

console.log(sports);

// Explicar la diferencia entre el tradicional concatenamiento de cadenas 
// y los String de plantillas utilizando el caracter de acento al contrario "`"
// `Hola mundo ${variable}`

// plantillas para operaciones matemáticas `1 + 2 = ${1 + 2}`

let a = `1 + 2 = ${1 + 2}`;
console.log("Operación: ", a)

// saltos de línea dentro de las templates, y diferencia con \n

// funciones flecha y diferencia con las otras funciones tradicionales

// funciones flecha con y sin paréntesis en los parámetros cuando solo hay un parámetro

// funciones flecha son y sin llaves en la función cuando solo existe una línea

// funciones flecha sin el return para retornar valores en una sola línea

// ejemplo de setTimeout con función flecha

// ejemplo del acceso a this con funciones flecha

var objectTest = {
    delay: function() {
        setTimeout(function() {
            this.doSomething();
        }, 1000);
    },

    doSomething: function() {
        alert('I did something');
    }
}

objectTest.delay();

// ahora implementar la función del settimeout con funciones flecha y ver la diferencia

// funciones con valores predeterminados, explicar el orden en que deben ir

// Explicar los valores predeterminados que pueden definirse previamente como variables

// Explicar el operador rest cuando se quiere recibir un número indefinido de parámetros en una función
// function (...parametros), se puede hacer el ejemplo de encontrar el valor máximo de un arreglo de parámetros
// o también el de buscar una palabra en un arreglo de parámetros

// Explicar el spread operator u operador de propagación y su diferencia con el rest
// donde spread se usa solo en el llamado de una función para convertir un array en parámetros
// se puede hacer el ejemplo con el Math.min(...array)

// Mostrar un ejemplo de combinación de rest y spread (puede ser el limpiar cadenas con trim)

// mostrar el ejemplo de uso de spread en la unión de varias listas ya definidas en una nueva que puede tener más valores adicionales a las listas a mezclar

// explicar el import (usar funcionalidades de un módulo) y el export (exponer funcionalidades de mi módulo para que sean usadas por otros) de los módulos en JS
// <script src="index.js" type="module"></script>
// export const pi = 3.1416;
// import {pi} from './path'

// explicar el export default, detallando que solo se puede usar una vez por cada módulo
// el import sería import funcinalidad from './path'

// explicar el import múltiple bajo un alias, haciendo un export para cada funcionalidad
// export function f1(){}
// export function f2(){}
// export function f3(){}
// import * as alias from './path'; y luego se llama f1, f2 y f3

// explicar los export en un solo objeto: export fn = {f1, f2, f3}
// import {fn} from './path'
// luego llamar a fn.f1()

// funcionamiento de las promesas

let prom = new Promise((resolve, reject) => {
    if (true) {
        resolve("Hello, It wroks!!! :-)")
    } else {
        reject("Hello, error! :-(")
    }
});

prom.then((result) => {
    console.log("Correct: ", result);
}).catch((error) => {
    console.log("Error: ", error);
});

// Explicar el fectch y su relación con el AJAX de JQuery
// https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch



// mezcla de las promesas con el fecth y explicar el formData

function getData(url) {
    return new Promise((resolve, reject) => {
        let formData = new FormData();
        formData.append('name', 'John');
        formData.append('password', 'John123');
        fetch(url, {
                body: formData,
                method: "post"
            })
            .then(response => {
                if (response.ok) {
                    return response.text();
                }
                reject('Error accessing the data: ' + response.status);
            })
            .then(texto => resolve(texto))
            .catch(err => reject(err));
    });
}

getData('data/info.json')
    .then(texto => console.log(texto))
    .catch(err => console.log('ERROR', err))


// Clases en JS

class Person {
    constructor(name, document) {
        this.name = name;
        this.document = document;
    }

    walk(meters) {
        console.log(`I'm walking for ${meters} meters...`)
    }
}

let person = new Person('Pepito', '123');
person.walk(2);


//Explicar el uso de super, el cual no se puede eliminar y se debe hacer en la primera línea del constructor
class boy extends Person() {
    constructor(name, document, toys) {
        super(name, document);
        this.toys = toys;
    }

    get name() {
        return this.name;
    }

    set name(name) {
        this.name = name;
    }

    // ¿Se puede hacer sobre-escritura de métodos? SI!!!
    walk(meters) {
        console.log(`I'm a boy, and I walking slower...`)
    }
}

// Explicar el uso de métodos static