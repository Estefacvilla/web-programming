// VAR - LET - CONST
var a = 1;
const y = 10;
//const z;

function changeValues() {
    a = 2;
    let x = 3;
    b = 7;
    //y = 12;
    var c = a * b * x;
    console.log("Resultado: ", c);
}

changeValues();
console.log("Valor final de 'a': ", a);
console.log("Valor final de 'b': ", b);
//console.log("Valor final de 'x': ", x);

const name = 'Pepito';
const age = 18;

const obj = {
    name: 'Pepito',
    age: 18
}

obj.name = 'Juanito';
console.log(obj.name);