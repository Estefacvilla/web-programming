let obj = {
    name: 'Pepito',
    age: 18
}
let message = 'Hola Mundo, soy ' + obj.name + " y tengo " + obj.age + " años.";
let prettyMessage = `Hola mundo, soy ${obj.name} y tengo ${obj.age} años.`;
console.log("Normal message: ", message);
console.log("pretty message: ", prettyMessage);

let result = `Resultado de 4 * 7: ${4 * 7}.`;
console.log(result);