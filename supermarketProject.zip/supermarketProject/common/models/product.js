'use strict';

module.exports = function (Product) {
    
    //By greater price
    Product.findByPriceGreater = function (price, cb) {
        Product.find({
            where: {
                price: {
                    gte: price
                }
            }
        }, cb);
    };

    Product.remoteMethod("findByPriceGreater", {
        accepts: {
            arg: "price",
            type: "number"
        },
        returns: {
            arg: "products",
            type: "array"
        },
        http: {
            path: "/get-product-by-greater-price",
            verb: "get"
        }
    })

// By less price

    Product.findByPriceLess = function (price, cb) {
        Product.find({
            where: {
                price: {
                    lt: price
                }
            }
        }, cb);
    };


    Product.remoteMethod("findByPriceLess", {
        accepts: {
            arg: "price",
            type: "number"
        },
        returns: {
            arg: "products",
            type: "array"
        },
        http: {
            path: "/get-product-by-less-price",
            verb: "get"
        }
    })

//Email

    Product.sendEmail = function (bodyMessage, cb) {
        let message = "This is my email message: " + bodyMessage;
        cb(null, message);
    };


    Product.remoteMethod("sendEmail", {
        accepts: {
            arg: "bodyMessage",
            type: "string"
        },
        returns: {
            arg: "message",
            type: "string"
        },
        http: {
            path: "/sendEmail",
            verb: "get"
        }
    })
};
















    // Product.findByGreaterPrice = function (price, cb) {

    //     Product.find({
    //         where: {
    //             price: {
    //                 gte: price
    //             }
    //         }
    //     }, cb);
    // };

    // Product.remoteMethod("findByGreaterPrice", {
    //     accepts: {
    //         arg: "price",
    //         type: "number"
    //     },
    //     returns: {
    //         arg: "products",
    //         type: "array"
    //     },
    //     http: {
    //         path: "/find-by-greater-price",
    //         verb: "get"
    //     }
    // });