'use strict';

module.exports = function (Category) {
    Category.sendEmail = (message, subject, emailAddresses, cb) => {
        Category.app.models.Email.send({
            to: emailAddresses,
            from: "James Bond - 007",
            subject: subject,
            text: message,
            html: message
        }, function (err, mail) {
            console.log("email sended!!!");
            if (err) return err;
        });
        cb(null, 'message sent: ' + message);
    }


    Category.remoteMethod('sendEmail',
        {
            http: {
                path: '/sendEmail', verb: 'get'
            },
            description: [
                "Api to send email messages."
            ],
            accepts: [
                {
                    arg: 'message',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'subject',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'emailAddresses',
                    type: 'string',
                    required: true
                }
            ],
            returns: { arg: 'reponse', type: 'string' }
        });
};
