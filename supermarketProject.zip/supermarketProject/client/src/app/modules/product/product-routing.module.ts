import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './admin/product-list/product-list.component';
import { ProductCreatorComponent } from './admin/product-creator/product-creator.component';
import { ProductEditorComponent } from './admin/product-editor/product-editor.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductHomeComponent } from './product-home/product-home.component';
import { UrlInjectionGuard } from 'src/app/guards/url-injection.guard';

const routes: Routes = [
  {
    path: 'admin/product/list',
    component: ProductListComponent,
    canActivate: [
      UrlInjectionGuard
    ]
  },
  {
    path: 'admin/product/creator',
    component: ProductCreatorComponent,
    canActivate: [
      UrlInjectionGuard
    ]
  },
  {
    path: 'admin/product/editor',
    component: ProductEditorComponent,
    canActivate: [
      UrlInjectionGuard
    ]
  },
  {
    path: 'product/home',
    component: ProductHomeComponent
  },
  {
    path: 'product/details/:id',
    component: ProductDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
