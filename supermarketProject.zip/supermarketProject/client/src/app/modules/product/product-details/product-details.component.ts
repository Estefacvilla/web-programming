import { Component, OnInit } from '@angular/core';
import { ProductModel } from 'src/app/models/product.model';
import { ProductService } from 'src/app/services/product.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private pdtService: ProductService, private route: ActivatedRoute) { }

  product: ProductModel = {
    barcode: null,
    category: null,
    code: null,
    id: null,
    image: null,
    name: null,
    offer: false,
    price: null,
    providerLink: null,
    stock: null
  }

  ngOnInit() {
    this.getProductInformation();
  }

  getProductInformation():void{
    let id = this.route.snapshot.params["id"];
    this.pdtService.getProductById(id).subscribe(item => {
      this.product = item;
    })
  }

}
