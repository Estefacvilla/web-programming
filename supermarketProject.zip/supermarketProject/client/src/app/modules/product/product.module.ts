import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductRoutingModule } from './product-routing.module';
import { ProductCreatorComponent } from './admin/product-creator/product-creator.component';
import { ProductEditorComponent } from './admin/product-editor/product-editor.component';
import { ProductHomeComponent } from './product-home/product-home.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './admin/product-list/product-list.component';

@NgModule({
  declarations: [ProductListComponent, ProductCreatorComponent, ProductEditorComponent, ProductHomeComponent, ProductDetailsComponent],
  imports: [
    CommonModule,
    ProductRoutingModule
  ],
  exports:[
    ProductListComponent, 
    ProductCreatorComponent,
    ProductEditorComponent,
    ProductHomeComponent,
    ProductDetailsComponent
  ]
})
export class ProductModule { }
