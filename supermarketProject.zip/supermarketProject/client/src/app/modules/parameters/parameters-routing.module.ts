import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategoryListComponent } from './category/category-list/category-list.component';
import { CategoryEditorComponent } from './category/category-editor/category-editor.component';
import { CategoryCreatorComponent } from './category/category-creator/category-creator.component';
import { UrlInjectionGuard } from 'src/app/guards/url-injection.guard';

const routes: Routes = [
  {
    path: 'admin/category/list',
    component: CategoryListComponent,
    canActivate: [
      UrlInjectionGuard
    ]
  },
  {
    path: 'admin/category/creator',
    component: CategoryCreatorComponent,
    canActivate: [
      UrlInjectionGuard
    ]
  },
  {
    path: 'admin/category/editor/:id',
    component: CategoryEditorComponent,
    canActivate: [
      UrlInjectionGuard
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ParametersRoutingModule { }
