import { Component, OnInit } from '@angular/core';
import { CategoryModel } from 'src/app/models/category.model';
import { CategoryService } from 'src/app/services/category.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner'
@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {

  constructor(private catService: CategoryService, private route: Router, private spinner: NgxSpinnerService) { }

  cp: number = 1;
  total: number = 0;

  showConfirmationButtons: boolean = false;

  categoryList: CategoryModel[] = [];

  idToSHowButtons: string = '';
  ngOnInit() {
    this.getAllCategories();
  }

  getAllCategories(): void {
    this.catService.getAllCategories().subscribe(items => {
      this.categoryList = items;
      this.total = items.length;
    })
  }

  ChangeConfirmationButtons(id) {
    this.idToSHowButtons = id;
    this.showConfirmationButtons = !this.showConfirmationButtons;
  }

  deleteCategory(categoryId: string): void {
    this.catService.deleteCategory(categoryId).subscribe(item => {
      console.log(item);
      this.route.navigate(["/admin/category/list"])
    })
  }

  onPageChange(event):void{
    this.spinner.show();
 
    this.cp = event;

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 3000);
  }

}
