import { Component, OnInit } from '@angular/core';
import { CategoryModel } from 'src/app/models/category.model';
import { CategoryService } from 'src/app/services/category.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-category-creator',
  templateUrl: './category-creator.component.html',
  styleUrls: ['./category-creator.component.css']
})
export class CategoryCreatorComponent implements OnInit {

  constructor(private catService: CategoryService, private router: Router) {
    this.categoryFormGroup = this.formGroupCreator();
  }

  categoryFormGroup: FormGroup;

  formGroupCreator(): FormGroup {
    return new FormGroup({
      code: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(10)]),
      name: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]),
      description: new FormControl('', [Validators.maxLength(100)])
    });
  }

  get code() {
    return this.categoryFormGroup.get('code');
  }

  get name() {
    return this.categoryFormGroup.get('name');
  }

  get description() {
    return this.categoryFormGroup.get('description');
  }

  ngOnInit() {
  }

  saveNewCategory(): void {
    if (this.categoryFormGroup.valid) {
      let category = this.buildCategoryData();
      this.catService.saveNewCategory(category).subscribe(item => {
        alert("The category has been stored successfully!!!");
        this.router.navigate(["/admin/category/list"]);
      });
      console.log("saved");
    } else {
      console.log("the form is invalid.");
    }
  }

  buildCategoryData(): CategoryModel {
    let category: CategoryModel = {
      id: null,
      code: this.code.value,
      name: this.name.value,
      description: this.description.value
    }
    return category;
  }

}
