export interface CategoryModel{
    id: string;
    code: string;
    name: string;
    description: string;
}