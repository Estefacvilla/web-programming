export interface ProductModel{
    id: string;
    code: string;
    name: string;
    stock: number;
    category: string;
    price: number;
    offer: boolean;
    barcode: string;
    image: string;
    providerLink: string;
}