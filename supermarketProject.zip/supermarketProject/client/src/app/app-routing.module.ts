import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ParametersModule } from './modules/parameters/parameters.module';
import { ProductModule } from './modules/product/product.module';
import { HomeComponent } from './template/home/home.component';
import { PageNotFoundComponent } from './template/page-not-found/page-not-found.component';
import { UsersModule } from './modules/users/users.module';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path:'',
    pathMatch: 'full',
    redirectTo: '/home'
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    ParametersModule,
    ProductModule,
    UsersModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
