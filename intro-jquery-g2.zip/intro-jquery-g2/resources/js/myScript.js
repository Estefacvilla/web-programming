$(document).ready(function() {

    //alert("Hola mundo desde el document ready!!!");

    //setTimeout('backgroundChangerFn("#0000FF")', 500);
    setInterval('backgroundChangerFn("#FFF", "#dedede")', 500);
    //addingDynamicDiv();
    $("#container").css("color", "#FFF");
    //eval("alert('hola desde el eval')");

    $("#citySelect").on("change", loadPeopleInfo);

});


/*
function backgroundChangerFn(color){

}

let backgroundChangerFn = function(color) {
    $("body").attr("style", "background-color: " + color);
}*/

var bgController = true;

let backgroundChangerFn = (color1, color2) => {
    //console.log("changing color")
    if (bgController) {
        $("body").attr("style", "background-color: " + color1);
    } else {
        $("body").attr("style", "background-color: " + color2);
    }
    bgController = !bgController;
}

var divIdController = 1;

let hideDymanicDiv = () => {
    let divId = $("#divId").val();
    if (divId != undefined && divId != "") {
        if ($("#divId-" + divId).length > 0) {
            $("#divId-" + divId).hide(4000);
        } else {
            alert("The div with id " + divId + " does not exists!")
        }
    } else {
        $(".dynamicDiv").hide(4000);
    }
}

let showDymanicDiv = () => {
    $(".dynamicDiv").show("slow");
}

let createDymanicDiv = () => {
    $("#container").append("<div id='divId-" + divIdController + "' class='dynamicDiv'>Hello from dynamic div! " + divIdController + "</div>");
    divIdController++;
}


let loadPeopleInfo = () => {
    $.ajax({
        url: "data/info.json",
        data: {},
        success: function(result) {
            let info = JSON.parse(result);
            let rows = "";
            let options = "";
            $(info).each(function(index, obj) {
                options += "<option value='" + obj.id + "'>" + obj.name + "</option>";
                rows += "<tr><td>" + obj.id + "</td><td>" + obj.name + "</td><td>" + obj.age + "</td></tr>"
            });
            $("#peopleInfo tbody").html(rows);
            $("#peopleSelect").html(options);
        }
    });
}