import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-editor',
  templateUrl: './product-editor.component.html',
  styleUrls: ['./product-editor.component.css']
})
export class ProductEditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
