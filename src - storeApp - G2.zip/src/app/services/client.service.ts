import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ClientService {

  constructor() { }

  getClientListInfo(){

    
    return [
      {
        id: 1,
        name: 'Pepito',
        balance: 3000
      },
      {
        id: 2,
        name: 'Juanita',
        balance: 5000
      },
      {
        id: 3,
        name: 'Pedrito',
        balance: 10000
      },
      {
        id: 4,
        name: 'Juanito Alimaña',
        balance: 100000
      }
    ];

    
  }
}
