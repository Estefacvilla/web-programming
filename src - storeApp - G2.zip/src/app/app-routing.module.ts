import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './general/home/home.component';
import { GeneralModule } from './general/general.module';
import { PageNotFoundComponent } from './general/page-not-found/page-not-found.component';
import { WorkerRoutingModule } from './worker/worker-routing.module';
import { ClientRoutingModule } from './client/client-routing.module';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/home'
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    GeneralModule,
    WorkerRoutingModule,
    ClientRoutingModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
