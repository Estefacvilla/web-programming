import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientListComponent } from './client-list/client-list.component';
import { ClientCreatorComponent } from './client-creator/client-creator.component';

@NgModule({
  declarations: [ClientListComponent, ClientCreatorComponent],
  imports: [
    CommonModule,
  ],
  exports: [
    ClientCreatorComponent,
    ClientListComponent
  ]
})
export class ClientModule { }
