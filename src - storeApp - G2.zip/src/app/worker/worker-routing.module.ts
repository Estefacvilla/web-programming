import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkerCreatorComponent } from './worker-creator/worker-creator.component';
import { WorkerModule } from './worker.module';
import { WorkerListComponent } from './worker-list/worker-list.component';

const routes: Routes = [
  {
    path: 'worker/creator',
    component: WorkerCreatorComponent
  },
  {
    path: 'worker/list',
    component: WorkerListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes), WorkerModule],
  exports: [RouterModule]
})
export class WorkerRoutingModule { }
