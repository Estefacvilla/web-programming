import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-worker-list',
  templateUrl: './worker-list.component.html',
  styleUrls: ['./worker-list.component.css']
})
export class WorkerListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
