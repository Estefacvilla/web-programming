import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WorkerListComponent } from './worker-list/worker-list.component';
import { WorkerCreatorComponent } from './worker-creator/worker-creator.component';

@NgModule({
  declarations: [WorkerListComponent, WorkerCreatorComponent],
  imports: [
    CommonModule
  ],
  exports: [
    WorkerCreatorComponent,
    WorkerListComponent
  ]
})
export class WorkerModule { }
