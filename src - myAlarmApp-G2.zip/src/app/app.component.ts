import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Alarm!!!';
  alarmMessage = "Eyyyy wake up please!!!";
  alarmClockArray = [];
  seconds = -1;
  alarmId = 1;

  generateRandomSecond(){
    this.seconds = Math.trunc(Math.random() * 60);
  }

  showMessage(info){
    this.alarmMessage = `${info.message} ${this.alarmMessage}`;
    this.alarmClockArray.push({id: this.alarmId, time: info.time, message: this.alarmMessage});
    this.alarmId++;
    this.seconds = info.time;
  }

}
