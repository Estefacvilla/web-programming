import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-alarm-clock',
  templateUrl: './alarm-clock.component.html',
  styleUrls: ['./alarm-clock.component.css']
})
export class AlarmClockComponent implements OnInit {

  @Input() startTime;
  @Output() notification = new EventEmitter();
  sentMessage = false;
  @Input() timeArray;
  timeTmp = undefined;
  constructor() { }

  ngOnInit() {
    setInterval(() => {
      if (this.startTime > 0) {
        if(this.timeTmp == undefined){
          this.timeTmp = this.startTime;
        }
        this.startTime--;
        this.sentMessage = false;
      } else {
        if (this.startTime == 0) {
          if (!this.sentMessage) {
            this.notification.emit({ time: this.timeTmp, message: 'Hi,' });
            this.sentMessage = true;
            this.timeTmp = undefined;
          }
        } else {
          this.startTime = '--';
        }
      }
    }, 100);
  }

}
