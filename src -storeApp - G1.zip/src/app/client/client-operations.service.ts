import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ClientOperationsService {

  constructor(private http: HttpClient) {

  }

saveNewClient(client){

}

  getClientListData() {

    return this.http.get('http://gitir.co/clients.json');

    return [
      {
        "id": 0,
        "isActive": false,
        "balance": "3759",
        "age": 40,
        "eyeColor": "blue",
        "name": "Jacquelyn Cote",
        "gender": "female",
        "company": "HYDROCOM",
        "email": "jacquelyncote@hydrocom.com",
        "phone": "+1 (924) 593-3040",
        "address": "240 Creamer Street, Ventress, Guam, 2959",
        "about": "Exercitation veniam amet do incididunt aliquip voluptate ullamco magna velit. Velit ad est culpa ad ullamco quis id. Enim ullamco enim reprehenderit dolor exercitation minim commodo enim irure duis velit ipsum ea officia. Quis eu nostrud do ullamco et. Qui reprehenderit exercitation commodo duis incididunt voluptate eu mollit voluptate non. Velit ut minim quis fugiat elit ex officia consectetur. Cillum veniam eu sint in tempor eiusmod duis tempor duis qui ad dolor aliquip.\r\n",
        "registered": "2017-06-09T11:19:22 +05:00",
        "latitude": 60.868925,
        "longitude": -137.50993,
        "friends": [
          {
            "id": 0,
            "name": "Vicky Bailey"
          },
          {
            "id": 1,
            "name": "Watkins Jacobson"
          },
          {
            "id": 2,
            "name": "Richmond Decker"
          }
        ],
        "greeting": "Hello, Jacquelyn Cote! You have 1 unread messages.",
        "favoriteFruit": "strawberry"
      },
      {
        "id": 1,
        "isActive": false,
        "balance": "1442",
        "age": 20,
        "eyeColor": "green",
        "name": "Cunningham Petty",
        "gender": "male",
        "company": "BLEENDOT",
        "email": "cunninghampetty@bleendot.com",
        "phone": "+1 (828) 427-3420",
        "address": "687 Jerome Avenue, Guilford, Texas, 4200",
        "about": "Pariatur laborum sint elit sit adipisicing pariatur ipsum. Excepteur irure adipisicing officia excepteur veniam velit id aute officia culpa aliquip. Reprehenderit in do duis eu aliquip anim quis magna laborum quis sint velit. Labore commodo elit labore reprehenderit elit aute duis adipisicing ut. Occaecat irure sit culpa in sunt reprehenderit aute ullamco consequat. Adipisicing mollit veniam officia ullamco dolore consequat. Sunt elit occaecat reprehenderit minim occaecat fugiat esse labore dolor in ullamco qui officia nostrud.\r\n",
        "registered": "2014-03-08T12:46:15 +05:00",
        "latitude": -59.73862,
        "longitude": 43.780635,
        "friends": [
          {
            "id": 0,
            "name": "Dejesus Lewis"
          },
          {
            "id": 1,
            "name": "Gabrielle Solomon"
          },
          {
            "id": 2,
            "name": "Tyson Olsen"
          }
        ],
        "greeting": "Hello, Cunningham Petty! You have 5 unread messages.",
        "favoriteFruit": "apple"
      },
      {
        "id": 2,
        "isActive": true,
        "balance": "2051",
        "age": 34,
        "eyeColor": "green",
        "name": "Rhea Conley",
        "gender": "female",
        "company": "ANDERSHUN",
        "email": "rheaconley@andershun.com",
        "phone": "+1 (866) 446-2918",
        "address": "236 Oriental Boulevard, Marion, Wisconsin, 4521",
        "about": "Mollit sunt minim excepteur in est ea proident qui ex ad in velit ex elit. Mollit irure enim non duis officia mollit est eiusmod culpa laborum. Esse eu Lorem cupidatat nisi laboris ut. Excepteur irure laborum dolore excepteur commodo adipisicing adipisicing esse laboris duis dolore officia anim. Mollit laborum magna nulla do esse culpa officia.\r\n",
        "registered": "2014-05-16T04:28:09 +05:00",
        "latitude": -71.337582,
        "longitude": -82.519414,
        "friends": [
          {
            "id": 0,
            "name": "Brandi Travis"
          },
          {
            "id": 1,
            "name": "Buckley Atkinson"
          },
          {
            "id": 2,
            "name": "Pauline Stevenson"
          }
        ],
        "greeting": "Hello, Rhea Conley! You have 4 unread messages.",
        "favoriteFruit": "strawberry"
      },
      {
        "id": 3,
        "isActive": true,
        "balance": "3795",
        "age": 25,
        "eyeColor": "green",
        "name": "Harmon Franco",
        "gender": "male",
        "company": "SULTRAX",
        "email": "harmonfranco@sultrax.com",
        "phone": "+1 (936) 500-3708",
        "address": "932 Maple Street, Franklin, Minnesota, 7105",
        "about": "Lorem ipsum esse voluptate id non aliqua fugiat veniam aliquip elit irure non. Culpa aliquip ea consectetur eiusmod consequat consectetur sit dolore sit ipsum. Nisi ea aliquip voluptate voluptate aute eiusmod pariatur sint ea ullamco cillum voluptate nulla.\r\n",
        "registered": "2015-03-25T08:09:04 +05:00",
        "latitude": 24.763916,
        "longitude": 88.723747,
        "friends": [
          {
            "id": 0,
            "name": "Abbott Dotson"
          },
          {
            "id": 1,
            "name": "Kathy Strickland"
          },
          {
            "id": 2,
            "name": "Alexis Gaines"
          }
        ],
        "greeting": "Hello, Harmon Franco! You have 1 unread messages.",
        "favoriteFruit": "strawberry"
      },
      {
        "id": 4,
        "isActive": false,
        "balance": "3354",
        "age": 33,
        "eyeColor": "brown",
        "name": "Schroeder Jordan",
        "gender": "male",
        "company": "ONTAGENE",
        "email": "schroederjordan@ontagene.com",
        "phone": "+1 (981) 554-2909",
        "address": "177 Calder Place, Clarktown, Connecticut, 8004",
        "about": "Est dolore ex quis veniam voluptate mollit veniam ea adipisicing consequat labore. Culpa pariatur eiusmod laborum eiusmod laboris ipsum deserunt. Commodo nostrud velit irure velit officia nulla nulla elit culpa veniam.\r\n",
        "registered": "2016-06-12T06:43:14 +05:00",
        "latitude": -57.66688,
        "longitude": 13.004329,
        "friends": [
          {
            "id": 0,
            "name": "Mavis Thompson"
          },
          {
            "id": 1,
            "name": "Theresa Hayden"
          },
          {
            "id": 2,
            "name": "Mendoza Welch"
          }
        ],
        "greeting": "Hello, Schroeder Jordan! You have 9 unread messages.",
        "favoriteFruit": "apple"
      },
      {
        "id": 5,
        "isActive": false,
        "balance": "3315",
        "age": 30,
        "eyeColor": "blue",
        "name": "Cassandra Mathis",
        "gender": "female",
        "company": "QOT",
        "email": "cassandramathis@qot.com",
        "phone": "+1 (863) 578-2488",
        "address": "785 Greenpoint Avenue, Chamizal, New Jersey, 9085",
        "about": "Et qui reprehenderit eiusmod est magna duis ea qui pariatur pariatur tempor. Elit ipsum esse in eiusmod magna enim commodo velit irure fugiat laboris. Enim consequat amet labore voluptate eu ex consectetur in. Consectetur aliqua esse officia elit ea. Duis anim dolor mollit cupidatat esse officia minim consequat mollit quis exercitation. Anim ad duis do aliqua duis exercitation nulla veniam elit occaecat incididunt velit. Aliquip consequat in mollit Lorem ipsum cupidatat proident nulla voluptate.\r\n",
        "registered": "2019-01-30T12:40:26 +05:00",
        "latitude": 9.772287,
        "longitude": 155.847998,
        "friends": [
          {
            "id": 0,
            "name": "Tina Gonzalez"
          },
          {
            "id": 1,
            "name": "Gill Owens"
          },
          {
            "id": 2,
            "name": "Kirsten Graham"
          }
        ],
        "greeting": "Hello, Cassandra Mathis! You have 9 unread messages.",
        "favoriteFruit": "banana"
      },
      {
        "id": 6,
        "isActive": false,
        "balance": "3102",
        "age": 21,
        "eyeColor": "brown",
        "name": "Randall Abbott",
        "gender": "male",
        "company": "MANGELICA",
        "email": "randallabbott@mangelica.com",
        "phone": "+1 (974) 565-2754",
        "address": "144 Butler Place, Matheny, South Dakota, 1879",
        "about": "Reprehenderit ullamco esse tempor exercitation cupidatat culpa sint elit nisi enim. Exercitation in dolor veniam officia voluptate nostrud. Consectetur enim culpa sit culpa anim dolor qui excepteur sit officia. Velit dolore consectetur nisi id incididunt tempor anim culpa veniam ullamco. Velit sit aliquip consectetur officia. Fugiat eu aute eu proident.\r\n",
        "registered": "2017-08-21T06:08:07 +05:00",
        "latitude": 66.738032,
        "longitude": -115.589848,
        "friends": [
          {
            "id": 0,
            "name": "Crawford Gillespie"
          },
          {
            "id": 1,
            "name": "Marjorie Mays"
          },
          {
            "id": 2,
            "name": "Lawson Watts"
          }
        ],
        "greeting": "Hello, Randall Abbott! You have 10 unread messages.",
        "favoriteFruit": "strawberry"
      }
    ];
  }

}

