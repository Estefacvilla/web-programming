import { Component, OnInit } from '@angular/core';
import { ClientOperationsService } from '../client-operations.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})
export class ClientListComponent implements OnInit {
  clientListData = [];
  constructor(private clientService: ClientOperationsService) { }

  ngOnInit() {
    this.clientListData = this.clientService.getClientListData();
  }

}
