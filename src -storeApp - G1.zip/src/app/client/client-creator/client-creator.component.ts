import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-creator',
  templateUrl: './client-creator.component.html',
  styleUrls: ['./client-creator.component.css']
})
export class ClientCreatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
