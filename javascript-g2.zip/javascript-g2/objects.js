let name = 'Pepito';
let age = 25;

let testObject = {
    name,
    age,
    salaries: [25, 12, 78, 36, 100],
    salaryAVG() {
        let sum = 0;
        this.salaries.forEach(s => {
            sum += s;
        });
        let avg = sum / this.salaries.length;
        console.log("Salary AVG: ", avg);
    }
}


testObject.salaryAVG()




var element = 'athletics'
var type = 'run'

function sport() {
    return 'marathon'
}

var sports = {
    [sport()]: element,
    [type + '100m']: 'type: run 100 meters',
    [type + '200m']: 'type: run 200 meters',
}

console.log(sports);