let obj = {
    name: 'Juanita',
    age: 15
}

let message = 'The student ' + obj.name + " is " + obj.age + " years old.";
let message2 = `The student ${obj.name} is ${obj.age} years old.`
let message3 = `The result of operation 2 * 5 is: ${2*5}`
console.log(message);

console.log(`----1------

------2------

-----3------`)

console.log(message2);
console.log(message3);