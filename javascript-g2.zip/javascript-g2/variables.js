var c = 0;
const d = 3;

function changingValues() {
    a = 5;
    let z = 7;
    var b = 3;
    //d = 12;
    c = a * b;
    console.log(c)
}

changingValues();
console.log("a: ", a);
//console.log("z", z);
console.log("Resultado de c: ", c);


console.log(`
----------------------
`)



const obj = {
    name: 'Juan',
    age: 28
}

obj.name = 'Pedro';

//obj = {}

console.log('obj.name: ', obj.name);

console.log(`
----------------------
`)

let { x = 5, y = 6, z = 7 } = { x: 1, y: 2 }
console.log("x: ", x);
console.log("z: ", z);