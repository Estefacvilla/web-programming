function fn1( /* parameters */ ) {
    // do something
}

let myFunction = () => {

}


let fn2 = ( /* parameters */ ) => {
    // do something with parameters
}

let fn3 = (a, b, c) => {
    return a * b * c;
}

let fn3New = (a, b, c) => a * b * c

let fnPow = x => x ** x
let myX = 4;
console.log(`Resultado de ${myX} ** ${myX}`, fnPow(myX));






// special case
let fn4 = x => x ** x;

console.log("Resultado: ", fn3(2, 3, 4));
console.log("Resultado potencia: ", fn4(3));

// funciones flecha con el settimeout
var objectTest = {
    delay: function() {
        setTimeout(() => {
            this.doSomething();
        }, 1000);
    },

    doSomething: function() {
        console.log('I did something from traditional settimeout.');
    }
}

objectTest.delay();

console.log(`
------------------------
`);

// valores predeterminados para los parámetros de las funciones.
let x = 25;
let fn5 = (a, b, c = x, d = true) => {
    console.log(`Recibímos los parámetros a, b, c y d. Sus valores son: a = ${a}, b = ${b}, c = ${c}, d = ${d}.`)
}

fn5("Ana", 25, "María");

console.log(`
------------------------
`);

let fn6 = ({ a, b, c = x, d = true }) => {
    console.log(`Recibímos en objeto los parámetros a, b, c y d. Sus valores son: a = ${a}, b = ${b}, c = ${c}, d = ${d}.`)
}

fn6({ a: 2, b: "I'm", d: "lola" })


console.log(`
------------------------
`);

// rest operator ...parameters => definición de funciones

let searchWord = (wordToSearch, ...words) => {
    console.log("To search: ", wordToSearch);
    words.forEach(w => {
        if (w == wordToSearch) {
            console.log(wordToSearch, " was found!");
            return;
        }
    });
}




searchWord("Perro", "Perro", "Naranja", "lola", "Computador", "casa");

console.log(`
------------------------
`);

// spread operator => igual que rest pero para llamar a una función
let arrayWords = ["Perro", "Tigre", "Gato", "Naranja", "lola", "Computador", "casa"];
console.log(arrayWords);
searchWord("Tigre", ...arrayWords);

console.log(`
------------------------
`);

let list1 = [1, 2, 3, 4, 5];
let list2 = ["Amazon", "Microsoft", "Apple", "Facebook"];
let list3 = [...list1, ...list2, true, false, {
    name: 'Pepito',
    age: 18
}, "UdC"];
console.log(list3);

console.log(`
------------------------
`);

list3.forEach(elem => {
    if (isNaN(parseInt(elem))) {
        console.log("Elemento normal ", elem);
    } else {
        console.log("Soy entenro", elem);
    }
})


console.log(`Tipo de 5: ${typeof(5)}`);