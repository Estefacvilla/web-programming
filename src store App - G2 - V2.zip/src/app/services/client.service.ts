import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ClientService {

  constructor() { }

  getClientListInfo() {
    return this.info;
  }

  searchClient(id) {
    return this.info.find(c => c.id == id);
  }

  updateClient(client) {
    let originalInfo = this.searchClient(client.id);
    if (originalInfo != null && originalInfo != undefined) {
      originalInfo.name = client.name;
      originalInfo.age = client.age;
      originalInfo.balance = client.balance;
      return true;
    }
    return false;
  }

  info = [
    {
      id: 1,
      name: 'Pepito',
      age: 18,
      balance: 3000
    },
    {
      id: 2,
      name: 'Juanita',
      age: 24,
      balance: 5000
    },
    {
      id: 3,
      name: 'Pedrito',
      age: 15,
      balance: 10000
    },
    {
      id: 4,
      name: 'Juanito Alimaña',
      age: 20,
      balance: 100000
    }
  ];

}
