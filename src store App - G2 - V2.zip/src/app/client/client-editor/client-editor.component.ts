import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClientService } from 'src/app/services/client.service';

@Component({
  selector: 'app-client-editor',
  templateUrl: './client-editor.component.html',
  styleUrls: ['./client-editor.component.css']
})
export class ClientEditorComponent implements OnInit {

  id;

  client = {
    id: null,
    name: null,
    age: null,
    balance: null
  }

  clientList = [];

  constructor(private route : ActivatedRoute, private clientService: ClientService) { }
  
  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get("clientId");
    let foundClient = this.clientService.searchClient(this.id);
    this.client.id = this.id;
    this.client.name = foundClient.name;
    this.client.age = foundClient.age;
    this.client.balance = foundClient.balance;
    this.clientList = this.clientService.getClientListInfo();
  }

  updateClient(){
    if(this.client.id != null){
      if(this.clientService.updateClient(this.client)){
        alert("Client has been updated!");
      }else{
        alert("This client does not exist!");
      }
    }
  }

}
