import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-worker-creator',
  templateUrl: './worker-creator.component.html',
  styleUrls: ['./worker-creator.component.css']
})
export class WorkerCreatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
