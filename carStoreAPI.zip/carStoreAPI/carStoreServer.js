/** Package imports */
const express = require('express');
const mongoose = require('mongoose');
const config = require('config');
const CarSchema = require('./models/CarModel');
const PersonSchema = require('./models/PersonModel');
const bodyParser = require('body-parser');
const cors = require('cors');

/** Database Connection */
const dbServerURL = config.get('mongoDbURL');
mongoose.connect(dbServerURL, { useNewUrlParser: true, useCreateIndex: true, useFindAndModify: false })
    .then(() => console.log('mongodb connected...'))
    .catch(err => console.log('Error connecting: ' + err))


/** Server settings */
const app = express();
const port = config.get('serverPort');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const corsOptions = {
    origin: 'http://localhost:4200',
    optionsSuccessStatus: 200
}

app.use(cors(corsOptions));

app.listen(port, () => {
    console.log('server has been started...');
});

/** REST API Methods */

app.get('/', (req, res) => {
    res.send('This is the API Rest root.');
});

app.get('/api/car/all', (req, res) => {
    CarSchema.find()
        .then(items => {
            res.status(200).send(items);
        })
        .catch(err => {
            res.status(500).send('Error: ' + err);
        })
});

app.get('/api/car/:id', (req, res) => {
    let carId = req.params.id;
    CarSchema.findById(carId)
        .then(item => {
            res.status(200).send(item);
        })
        .catch(err => {
            res.status(500).send('Error: ' + err);
        })
});

app.get('/api/carbyplate/:plate', (req, res) => {
    let carPlate = req.params.plate;
    CarSchema.findOne({ plate: carPlate })
        .then(item => {
            res.status(200).send(item);
        })
        .catch(err => {
            res.status(500).send('Error: ' + err);
        })
});


app.post('/api/car', (req, res) => {
    console.log(req.body);
    let newCar = new CarSchema(req.body);
    newCar.save()
        .then(doc => {
            console.log('document saved');
            res.status(200).send(doc);
        })
        .catch(err => {
            console.log('Error: ' + err);
            res.status(500).send(err);
        });
});


app.put('/api/car', (req, res) => {
    console.log(req.body);
    CarSchema.findByIdAndUpdate(req.body._id, req.body, { new: true })
        .then(doc => {
            console.log('document updated');
            res.status(200).send(doc);
        })
        .catch(err => {
            console.log('Error: ' + err);
            res.status(500).send(err);
        });
});


/** Delete an existing product */
app.delete('/api/car', (req, res) => {
    CarSchema.findByIdAndDelete(req.body._id)
        .then(item => {
            console.log('car removed');
            res.status(200).send(item);
        })
        .catch(err => {
            console.log(err);
            res.status(500).send(err);
        })
});


/** Person API Methods */
app.post('/api/person', (req, res) => {
    console.log(req.body);
    let newPerson = new PersonSchema(req.body);
    newPerson.save()
        .then(doc => {
            console.log('document saved');
            res.status(200).send(doc);
        })
        .catch(err => {
            console.log('Error: ' + err);
            res.status(500).send(err);
        });
});

app.get('/api/person/:id', (req, res) => {
    let personId = req.params.id;
    PersonSchema.findById(personId)
        .then(item => {
            res.status(200).send(item);
        })
        .catch(err => {
            res.status(500).send('Error: ' + err);
        })
});
