const mongoose = require('mongoose');

const personSchema = new mongoose.Schema({
    document:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    birthDate:{
        type: Date,
        required: true
    }
});

const PersonModel = mongoose.model('Person_Coll', personSchema);

module.exports = PersonModel;