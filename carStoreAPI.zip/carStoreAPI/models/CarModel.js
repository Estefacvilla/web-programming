const mongoose = require('mongoose');

const carSchema = new mongoose.Schema({
    plate:{
        type: String,
        required: true
    },
    owner:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Person_Coll'
    },
    color:{
        type: String,
        required: true
    },
    year:{
        type: Number,
        required: true
    },
    description:{
        type: String,
        required: false
    }
});

const CarModel = mongoose.model('Car_Coll', carSchema);

module.exports = CarModel;